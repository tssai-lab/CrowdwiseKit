1. python setup.py install --install-purelib install --install-platlib install
2. mv install/CUBAM-1.0-py2.7.egg-info CUBAM-1.0-py2.7.egg-info 
mv install/cubamcpp.so cubamcpp.so
3. run cubam.py
