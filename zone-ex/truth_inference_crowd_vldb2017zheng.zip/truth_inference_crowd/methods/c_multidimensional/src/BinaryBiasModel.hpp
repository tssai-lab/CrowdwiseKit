#ifndef __BinaryBiasModel_hpp__
#define __BinaryBiasModel_hpp__

#include "BinaryModel.hpp"

class BinaryBiasModel : public BinaryModel {
};

#endif
